<?php
/**
* @author Ascaliko
*/
class Api extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
	}

	/*Pengiriman*/
	public function pengiriman_read(){

	}

	public function pengiriman_create(){

	}

	public function pengiriman_update(){

	}

	public function pengiriman_delete(){

	}
	/*End Pengiriman*/

	/*Tracking*/
	public function tracking_read(){

	}

	public function tracking_create(){

	}

	public function tracking_update(){

	}

	public function tracking_delete(){

	}
	/*End Tracking*/
}
?>