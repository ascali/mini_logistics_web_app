<?php
echo heading('Lowongan Pekerjaan', 3);
echo "<div class='well'>";
echo "Tidak ada data yang ditampilkan.";
echo "</div>";
?>