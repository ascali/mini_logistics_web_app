<?php 
echo heading('Perusahaanan Rekanan', 3);
echo "<div class='well'>";
echo "Tidak ada data yang ditampilkan.";
echo "</div>";
?>