<h3>RIWAYAT PERUSAHAAN</h3>
<p align="justify">
	<b>PT. Multiartha Retalindo Lestari (Nawala Express Courier)</b> adalah group perusahaan dan salah satu bidang usaha  jasa yang bergerak dalam bidang pengiriman  barang Domestik atau dalam Negeri di Indonesia, Ijin Penyelenggaraan POS diterbitkan oleh : Menteri Komunikasi dan Informatika Republik Indonesia Tgl. 10 Oktober 2019 Nomor, 127/POS.01.00/ FD/2019 dan merupakan Kurir Nasional.
</p>
<p align="justify">
	Perusahaan kami  telah berpengalaman dalam pengiriman barang dan dokumen  ke  wilayah Indonesia, yang khusus dipergunakan oleh Dunia perbankkan.
</p>
<p align="justify">
	Tahun 2019 ini kami mulai dengan jasa kurir ritel dan kargo pelayanan umum untuk semua angkutan barang.
</p>

<hr>

<h4>VISI DAN MISI</h4>
<b>VISI</b>
<p align="justify">
Menjadi perusahaan pengiriman barang dan dokumen yang dapat diandalkan dan dipercaya dengan selalu meningkatkan mutu kualitas pelayanan dengan keunggulan yang tidak dimiliki oleh Jasa kurir laiinya, yaitu pengiriman cepat, fresh dan hygienis.

</p>
<b>MISI</b>
<p align="justify">
Membangun jalur distribusi yang efektif dan efesien
Mendorong usaha UKM , produksi local, kuliner makanan khas, dan produk produk  UKM  dapat dilayani  dengan baik dan barang yang dikirim tetap Frseh dan Hgynes. Mengutamakan kualitas dalam melayani pelanggan
</p>

	
