<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
	<h1 class="h2">Beranda <?= $this->session->userdata('nama_cabang'); ?></h1>
</div>
<div class="d-flex p-2 bd-highlight">
	<p>
		Ini adalah halaman Admin yang diperuntukkan untuk <strong>Karyawan <em>PT. Multiartha Retalindo Lestari</em></strong>
		<br>
		Pastikan hanya karyawan internal saja yang dapat mengakses halaman ini.
	</p>
</div>

<!-- <h3>Chart Pengiriman</h3>
<canvas class="my-4 w-100" id="myChart" width="900" height="380"></canvas> -->

<h3>Customer</h3>
<div class="table-responsive">
<table class="table table-striped table-sm" id="dataTable" style="width:100%">
  <thead>
    <tr>
      <th>Nama</th>
      <th>Email</th>
      <th>No Telp</th>
      <th>Perusahaan</th>
      <th>Kota</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
</div>